// ILikeBanas


#include "FSRailroadSwitchOperator.h"
#include "Buildables/FGBuildableRailroadSwitchControl.h"


AFGHologram* UFSRailroadSwitchOperator::CreateHologram()
{
	return nullptr;
}

void UFSRailroadSwitchOperator::UpdateHologramState(const FHitResult& Hit, AFGHologram* Hologram, bool& ShouldShow, bool& Valid)
{

}

AFGHologram* UFSRailroadSwitchOperator::HologramCopy(FTransform& RelativeTransform)
{
	return nullptr;
}

AFGBuildable* UFSRailroadSwitchOperator::CreateCopy(const FSTransformOperator& TransformOperator)
{
	return nullptr;
}