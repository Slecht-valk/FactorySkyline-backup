// ILikeBanas

#pragma once

#include "CoreMinimal.h"
#include "UObject/NoExportTypes.h"
#include "Buildables/FGBuildable.h"
#include "FSBuildableOperator.h"
#include "FSFactoryOperator.h"
#include "FSGeneratorOperator.generated.h"

/**
 * 
 */
UCLASS()
class FACTORYSKYLINE_API UFSGeneratorOperator : public UFSFactoryOperator
{
	GENERATED_BODY()
public:


};
