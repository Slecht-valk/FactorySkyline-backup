// ILikeBanas


#include "FSBuildingOperator.h"
#include "Buildables/FGBuildableFactoryBuilding.h"


FSBuildableType UFSBuildingOperator::GetType() const
{
	return FSBuildableType::Building;
}
