// ILikeBanas


#include "FSSyncWork.h"

void UFSSyncWork::Load()
{
}

void UFSSyncWork::Unload()
{
}

bool UFSSyncWork::DoWork(float TimeLimit)
{
	return false;
}

int UFSSyncWork::GetTotal()
{
	return 0;
}

int UFSSyncWork::GetCurrent()
{
	return 0;
}
