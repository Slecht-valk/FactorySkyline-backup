// ILikeBanas

#pragma once

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "FSCopyOptionsPanel.generated.h"

/**
 * 
 */
UCLASS()
class FACTORYSKYLINE_API UFSCopyOptionsPanel : public UUserWidget
{
	GENERATED_BODY()
public:
	UFSCopyOptionsPanel(const FObjectInitializer& ObjectInitializer);
	
};
