// ILikeBanas


#include "FactorySkyline/UI/FSFoldWidgetBase.h"


UFSFoldWidgetBase::UFSFoldWidgetBase(const FObjectInitializer& ObjectInitializer)
	:Super(ObjectInitializer)
{
}
