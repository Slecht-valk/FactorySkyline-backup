// ILikeBanas

#pragma once

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "FSItemShortcut.generated.h"

/**
 * 
 */
UCLASS()
class FACTORYSKYLINE_API UFSItemShortcut : public UUserWidget
{
	GENERATED_BODY()
public:
	UFSItemShortcut(const FObjectInitializer& ObjectInitializer);
	
};
