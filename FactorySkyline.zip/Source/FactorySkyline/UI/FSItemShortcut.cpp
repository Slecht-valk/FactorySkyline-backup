// ILikeBanas


#include "FSItemShortcut.h"

UFSItemShortcut::UFSItemShortcut(const FObjectInitializer& ObjectInitializer)
	:Super(ObjectInitializer)
{
}