// ILikeBanas


#include "FSCopyOptionsPanel.h"


UFSCopyOptionsPanel::UFSCopyOptionsPanel(const FObjectInitializer& ObjectInitializer)
	:Super(ObjectInitializer)
{
}